import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl, ValidatorFn } from '@angular/forms';
import { MatStepper } from '@angular/material/stepper';
import { Subscription } from 'rxjs/Subscription';
import { AppService } from './app.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  stepName = ['Contact info', 'Areas', 'Address', 'Password', 'Completed']
  email = new FormControl('', [Validators.required, Validators.email]);
  contactInfoForm: FormGroup;
  secondFormGroup: FormGroup;
  addressForm: FormGroup;
  passwordForm: FormGroup;
  @ViewChild('stepper') stepper: MatStepper;
  hide = true;
  tab: number = 0;

  constructor(public appService: AppService) { }

  ngOnInit() {
    // this.contactInfoForm = this._formBuilder.group({
    //   firstCtrl: ['', Validators.required],
    //   secondCtrl: ['', Validators.email],
    //   thirdCtrl: ['', Validators.required],
    //   fourthCtrl: ['', [Validators.email, this.matchOtherValidator('secondCtrl')]],
    //   fifthCtrl: [''],
    //   sixthCtrl: ['', [Validators.required, Validators.minLength(9)]],
    //   seventhCtrl: ['', Validators.required],
    //   eighthCtrl: [''],
    //   ninethCtrl: ['', Validators.required],
    //   tenthCtrl: [''],
    //   eleventhCtrl: ['', Validators.required],
    // });
    // this.secondFormGroup = this._formBuilder.group({
    //   secondCtrl: ['', Validators.required],
    // });
    // this.addressForm = this._formBuilder.group({
    //   firstCtrl: ['', Validators.required],
    //   secondCtrl: ['Test', Validators.required],
    //   thirdCtrl: ['', Validators.required],
    //   fourthCtrl: ['', Validators.required],
    //   fifthCtrl: ['', Validators.required],
    //   sixthCtrl: ['', Validators.required],
    // });
    // this.passwordForm = this._formBuilder.group({
    //   firstCtrl: ['', Validators.required],
    //   secondCtrl: ['', [Validators.required, this.matchOtherValidator('firstCtrl')]],
    //   thirdCtrl: [false, Validators.requiredTrue],
    // });
    // this.subscribeOnForm();
  }

  // subscribeOnForm() {
  //   this.contactInfoForm.valueChanges.subscribe(val => {
  //     this.contactInfoForm.setValue(val, { emitEvent: false });
  //   });
  //   this.secondFormGroup.valueChanges.subscribe(val => {
  //     this.secondFormGroup.setValue(val, { emitEvent: false });
  //   });
  //   this.addressForm.valueChanges.subscribe(val => {
  //     this.addressForm.setValue(val, { emitEvent: false });
  //   });
  //   this.passwordForm.valueChanges.subscribe(val => {
  //     this.passwordForm.setValue(val, { emitEvent: false });
  //   });
  // }
  // getErrorMessage() {
  //   if (this.email.hasError('required')) {
  //     return 'You must enter a value';
  //   }
  //   return this.email.hasError('email') ? 'Not a valid email' : '';
  // }

  stepperChangeTab(key: string) {
    switch (key) {
      case "up":
        this.stepper.selectedIndex++;
        this.tab = this.stepper.selectedIndex;
        break;
      case "down":
        this.stepper.selectedIndex--;
        this.tab = this.stepper.selectedIndex;
        break;
      case "click":
        this.tab = this.stepper.selectedIndex;
        break;
    }
  }
  
  // matchOtherValidator(otherControlName: string): ValidatorFn {
  //   return (control: AbstractControl): { [key: string]: any } => {
  //     const otherControl: AbstractControl = control.root.get(otherControlName);

  //     if (otherControl) {
  //       const subscription: Subscription = otherControl
  //         .valueChanges
  //         .subscribe(() => {
  //           control.updateValueAndValidity();
  //           subscription.unsubscribe();
  //         });
  //     }

  //     return (otherControl && control.value !== otherControl.value) ? { match: true } : null;
  //   };
  // }
}
