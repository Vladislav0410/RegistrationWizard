import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { AppService } from '../app.service';
@Component({
  selector: 'app-areas',
  templateUrl: './areas.component.html',
  styleUrls: ['./areas.component.scss']
})
export class AreasComponent implements OnInit, OnDestroy {
    formAreas: FormGroup;
    constructor(private _appService: AppService) {

     }

    ngOnInit() {
        this.formAreas = this._appService.form.controls.areasForm as FormGroup;
        this.formAreas.valueChanges.subscribe(val => this._appService.form.controls.areasForm.patchValue(val,{emitEvent: false}))
    }

    ngOnDestroy(){
      // this.formAddress.unsubscribe();
    }

  }
