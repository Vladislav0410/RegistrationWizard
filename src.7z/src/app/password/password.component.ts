import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service';


@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.scss']
})
export class PasswordComponent implements OnInit, OnDestroy {
  hide = true;
  formPassword: FormGroup;
  constructor(private _appService: AppService) {

   }
   ngOnInit() {
    this.formPassword = this._appService.form.controls.passwordForm as FormGroup;
    this.formPassword.valueChanges.subscribe(val => this._appService.form.controls.passwordForm.patchValue(val,{emitEvent: false}))
}

ngOnDestroy(){
  // this.formAddress.unsubscribe();
}

}
