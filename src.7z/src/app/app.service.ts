import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl, ValidatorFn } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';

@Injectable({
    providedIn: 'root',
})

export class AppService {
    form: FormGroup;
constructor(private _formBuilder: FormBuilder) {
    this.form = this._formBuilder.group({
        contactInfoForm : this._formBuilder.group({
            firstCtrl: ['', Validators.required],
            secondCtrl: ['', Validators.email],
            thirdCtrl: ['', Validators.required],
            fourthCtrl: ['', [Validators.email, this.matchOtherValidator('secondCtrl')]],
            fifthCtrl: [''],
            sixthCtrl: ['', [Validators.required, Validators.minLength(9)]],
            seventhCtrl: ['', Validators.required],
            eighthCtrl: [''],
            ninethCtrl: ['', Validators.required],
            tenthCtrl: [''],
            eleventhCtrl: ['', Validators.required],
          }),
          areasForm : this._formBuilder.group({
            secondCtrl: ['', Validators.required],
          }),
          addressForm : this._formBuilder.group({
            firstCtrl: ['', Validators.required],
            secondCtrl: ['Test', Validators.required],
            thirdCtrl: ['', Validators.required],
            fourthCtrl: ['', Validators.required],
            fifthCtrl: ['', Validators.required],
            sixthCtrl: ['', Validators.required],
          }),
          passwordForm : this._formBuilder.group({
            firstCtrl: ['', Validators.required],
            secondCtrl: ['', [Validators.required, this.matchOtherValidator('firstCtrl')]],
            thirdCtrl: [false, Validators.requiredTrue],
          }),
    });
 }

 matchOtherValidator(otherControlName: string): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
      const otherControl: AbstractControl = control.root.get(otherControlName);

      if (otherControl) {
          const subscription: Subscription = otherControl
              .valueChanges
              .subscribe(() => {
                  control.updateValueAndValidity();
                  subscription.unsubscribe();
              });
      }

      return (otherControl && control.value !== otherControl.value) ? {match: true} : null;
  };
}
}
