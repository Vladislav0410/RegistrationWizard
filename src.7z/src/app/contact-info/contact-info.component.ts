import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service';

@Component({
  selector: 'app-contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: ['./contact-info.component.scss']
})
export class ContactInfoComponent implements OnInit, OnDestroy {
  formContactInfo: FormGroup;
  constructor(private _appService: AppService) {

   }

   ngOnInit() {
    this.formContactInfo = this._appService.form.controls.contactInfoForm as FormGroup;
    this.formContactInfo.valueChanges.subscribe(val => this._appService.form.controls.contactInfoForm.patchValue(val,{emitEvent: false}))
}

ngOnDestroy(){
  // this.formAddress.unsubscribe();
}

}
